import React from 'react'

export default function DeleteRevieww() {
  return (
    <div>
      
    </div>
  )
}
