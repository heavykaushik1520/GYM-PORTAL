package com.project.bl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeastLifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
